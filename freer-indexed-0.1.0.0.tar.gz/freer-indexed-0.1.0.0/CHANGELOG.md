## 0.1.0.0

- Initial release
- Includes `XFreer` data type, `XApplicative` and `XMonad` classes
